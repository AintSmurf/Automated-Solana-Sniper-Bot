HELIUS = {
    "LOGS_SOCKET_MAINNET": "wss://mainnet.helius-rpc.com/?api-key=",
    "LOGS_SOCKET_DEVNET": "wss://devnet.helius-rpc.com/?api-key=",
}
